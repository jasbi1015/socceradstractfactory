package partes;

public interface Defensor {

    public String barrida();
    public String despeje();
    public String cabezazoDefensivo();
    
}
