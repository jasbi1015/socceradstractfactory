package partes;

public class ArqueroMujer implements Arquero {

    @Override 

    public String tirarseIzquierda(){

        return "tirarse izquierda mujer";

    }

    @Override 

    public String saqueArco(){

        return "patear balon  mujer";

    }

    @Override

    public String tirarseDerecha(){

        return "tirarse a la derecha mujer";

    }
    
}
