package partes;

public interface DefensorHombre {
    
}
