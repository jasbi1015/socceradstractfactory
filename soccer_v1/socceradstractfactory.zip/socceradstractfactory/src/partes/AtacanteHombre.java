package partes;

public class AtacanteHombre implements Atacante{


@Override
      public String patearArco() {

        return "";


      } 

@Override
        
    public String gambetear(){

        return "";
    }
      
@Override

    public String cabezasoOfensivo(){

        return "";
    }
    
}
