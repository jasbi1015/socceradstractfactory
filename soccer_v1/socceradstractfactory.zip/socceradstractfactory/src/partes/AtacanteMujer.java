package partes;

public class AtacanteMujer implements Atacante{

    @Override

    public String patearArco(){

        return "";


    }
    public String gambetear(){

        return "";
    }
    public String cabezasoOfensivo(){

        return "";
    }
    
}
