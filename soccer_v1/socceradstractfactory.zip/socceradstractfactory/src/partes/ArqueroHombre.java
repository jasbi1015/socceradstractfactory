package partes;

public class ArqueroHombre implements Arquero{

    @Override 

    public String tirarseIzquierda(){

        return "tirarse izquierda hombre";

    }

    @Override 

    public String saqueArco(){

        return "patear balon  hombre";

    }

    @Override

    public String tirarseDerecha(){

        return "tirarse a la derecha hombre";

    }
}

