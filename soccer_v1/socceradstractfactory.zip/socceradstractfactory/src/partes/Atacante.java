package partes;

public interface Atacante {

    public String patearArco();
    public String gambetear();
    public String cabezasoOfensivo();
    
}
