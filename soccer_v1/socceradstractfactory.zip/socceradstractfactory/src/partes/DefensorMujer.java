package partes;

public interface DefensorMujer {
    
}
