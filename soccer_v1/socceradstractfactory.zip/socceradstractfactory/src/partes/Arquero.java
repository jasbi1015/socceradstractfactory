package partes;

public interface Arquero {

    public String tirarseIzquierda();
    public String saqueArco();
    public String tirarseDerecha();
    
}
